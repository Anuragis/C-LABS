/***** Complete this file. *****/
#include "BookNode.h"
#include "Book.h"
#include "BookList.h"

BookNode::BookNode(Book book){
   this->book= book;
}

BookNode::BookNode(){
   
}