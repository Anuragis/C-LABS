/***** Complete this file. *****/
#include "BookNode.h"
#include "Book.h"
#include "BookList.h"

/** Create node objects using constructors*/

BookNode::BookNode(Book book){
   this->book= book;
}

BookNode::BookNode(){
   
}