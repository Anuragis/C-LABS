#include <iostream>
#include <iterator>
#include "SortedList.h"
#include "Node.h"
#include <vector>
#include <algorithm>
using namespace std;

SortedList::SortedList()
{
    Node::reset();
}

SortedList::~SortedList()
{
    Node::reset();
}

int SortedList::size() const { return data.size(); }

bool SortedList::check()
{
    if (data.size() == 0) return true;

    list<Node>::iterator it = data.begin();
    list<Node>::iterator prev = it;

    it++;

    // Ensure that each node is greater than the previous node.
    while ((it != data.end()) && (*it > *prev))
    {
        prev = it;
        it++;
    }

    return it == data.end();  // Good if reached the end.
}

void SortedList::prepend(const long value)
{
    /***** Complete this function. *****/
    list<Node>::iterator it;
    it=data.begin();
    Node val(value);
    it=data.insert(it,val);
}

void SortedList::append(const long value)
{
    /***** Complete this function. *****/
    Node val(value);
    data.push_back(val);
}

void SortedList::remove(const int index)
{
    /***** Complete this function. *****/
   list<Node>::iterator it=data.begin();
   if (data.size() > index)
   {
    std::advance(it, index);
   }
   it=data.erase(it);
}

void SortedList::insert(const long value)
{
    /***** Complete this function. *****/
    if(data.size() == 0)
	{
		data.push_front(value);
	}
	else
	{
		//int temp = data.size();
		list<Node>::iterator it;
		for (it = data.begin() ; it != data.end() ; it++)
		{
			//Node* temp = new Node(value);
			if (*it > value)
			{
				data.insert(it,value);
				break;
			}
		}
		if (it == data.end())
		{
			data.insert(it,value);
		}

	}
}

Node SortedList::at(const int index)
{
    /***** Complete this function. *****/
   list<Node>::iterator it=data.begin();
   if (data.size() > index)
   {
    std::advance(it, index);
    // 'it' points to the element at index 'N'
   }
    return *it;
}
